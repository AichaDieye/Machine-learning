import Formulaire from './form';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       
        <p>
          <Formulaire/>
        </p>
        
      </header>
    </div>
  );
}

export default App;
